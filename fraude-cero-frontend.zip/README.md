# Fraude Cero – Frontend (Next.js 14 + Tailwind)

Landing + Playground para probar el endpoint `POST /api/analizar` del backend (FastAPI). Incluye:
- Landing accesible (alto contraste, tipografía grande).
- CTA a Figma y Swagger.
- **Playground** que llama a `/api/analizar` (proxy server-side) para evitar CORS.
- Dockerfile y `render.yaml` para deploy fácil en Render.

## Requisitos
- Node.js >= 18.18
- npm

## Configuración
Copia `.env.local.example` a `.env.local` y ajusta variables si necesitas:
```bash
cp .env.local.example .env.local
```

## Desarrollo
```bash
npm install
npm run dev
# abre http://localhost:5173
```

## Producción
```bash
npm run build
npm start
# abre http://localhost:3000
```

## Deploy en Render (SIN Docker)
1. Crea un nuevo **Web Service** en Render conectado a tu repo.
2. *Build Command*: `npm install && npm run build`
3. *Start Command*: `npm start`
4. Agrega variable de entorno `API_ENDPOINT=https://fraudecero.onrender.com/api/analizar`

## Deploy en Render (CON Docker)
1. Elige **Blueprint** y sube `render.yaml`, o crea un **Web Service** desde Dockerfile.
2. Render construirá la imagen y expondrá el puerto 3000.

## Notas de seguridad
- Usa solo **mensajes ficticios** durante demos.
- El proxy **NO almacena** mensajes; solo reenvía y devuelve respuesta.
- Ajusta headers y límites si agregas autenticación al backend.

## Estructura
```
app/
  api/analizar/route.ts  # Proxy server-side → evita CORS
  layout.tsx
  page.tsx               # Renderiza el Landing
components/
  FraudeCeroLanding.tsx  # Landing + Playground
public/
  logo.svg
```

¡Éxitos con tu entrega!
