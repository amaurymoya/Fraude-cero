import FraudeCeroLanding from '@/components/FraudeCeroLanding'

export default function Page() {
  return <FraudeCeroLanding />
}
