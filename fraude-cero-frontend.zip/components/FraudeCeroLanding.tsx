'use client'

import React, { useMemo, useRef, useState } from 'react'
import { motion } from 'framer-motion'

const FIGMA_URL =
  'https://www.figma.com/make/BFdP8dbOzbDeNRYQlqBTm9/Mockup-App-Fraude-Cero?node-id=0-1&p=f&t=XpuGLYDzI2Q7hiFk-0&fullscreen=1'
const API_DOCS_URL =
  'https://fraudecero.onrender.com/docs#/default/analizar_mensaje_api_analizar_post'

export default function FraudeCeroLanding() {
  const demoRef = useRef<HTMLDivElement | null>(null)
  const [msg, setMsg] = useState('')
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [result, setResult] = useState<any>(null)

  const examples = useMemo(
    () => [
      'Hola, soy del banco. Necesito que me compartas tu clave por seguridad.',
      'Te ganaste un premio. Ingresa al siguiente enlace y pon tu RUT y tarjeta.',
      'Tu cuenta será bloqueada hoy. Paga esta “tarifa de verificación” ahora.',
    ],
    []
  )

  const handleAnalyze = async () => {
    setError(null)
    setResult(null)
    if (!msg.trim()) {
      setError('Escribe un mensaje a analizar.')
      return
    }
    try {
      setLoading(true)
      const res = await fetch('/api/analizar', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ mensaje: msg }),
      })
      if (!res.ok) {
        const t = await res.text()
        throw new Error(`Error ${res.status}: ${t}`)
      }
      const data = await res.json()
      setResult(data)
    } catch (e: any) {
      setError(e?.message || 'Error de red.')
    } finally {
      setLoading(false)
    }
  }

  const pretty = (x: any) => {
    try {
      return JSON.stringify(x, null, 2)
    } catch {
      return String(x)
    }
  }

  const scrollToDemo = () => demoRef.current?.scrollIntoView({ behavior: 'smooth' })

  return (
    <div className="min-h-screen bg-neutral-50 text-neutral-900">
      {/* Navbar */}
      <header className="sticky top-0 z-50 backdrop-blur bg-white/70 border-b border-neutral-200">
        <nav className="mx-auto max-w-6xl px-4 py-3 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="h-8 w-8 rounded-2xl bg-neutral-900" aria-hidden />
            <span className="font-bold text-lg tracking-tight">Fraude Cero</span>
          </div>
          <div className="flex items-center gap-2">
            <a
              href={FIGMA_URL}
              target="_blank"
              rel="noreferrer"
              className="px-3 py-2 rounded-xl text-sm font-medium bg-neutral-900 text-white hover:opacity-90"
            >
              Ver Figma
            </a>
            <a
              href={API_DOCS_URL}
              target="_blank"
              rel="noreferrer"
              className="px-3 py-2 rounded-xl text-sm font-medium border border-neutral-300 hover:bg-neutral-100"
            >
              API Docs
            </a>
            <button
              onClick={scrollToDemo}
              className="px-3 py-2 rounded-xl text-sm font-medium border border-neutral-900"
            >
              Probar Demo
            </button>
          </div>
        </nav>
      </header>

      {/* Hero */}
      <section className="mx-auto max-w-6xl px-4 py-16 grid gap-8 md:grid-cols-2 items-center">
        <div>
          <motion.h1
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="text-4xl md:text-5xl font-extrabold tracking-tight"
          >
            Copiloto de seguridad para prevenir estafas digitales
          </motion.h1>
          <p className="mt-4 text-lg leading-relaxed text-neutral-700">
            Diseñado para adultos mayores y cuidadores. Analiza mensajes y enlaces con un
            lenguaje claro, muestra un <span className="font-semibold">score de riesgo</span> y sugiere acciones
            rápidas (bloquear, reportar, verificar).
          </p>
          <div className="mt-6 flex flex-wrap items-center gap-3">
            <button
              onClick={scrollToDemo}
              className="px-5 py-3 rounded-2xl bg-neutral-900 text-white text-sm font-semibold hover:opacity-90"
            >
              Probar ahora
            </button>
            <a
              className="px-5 py-3 rounded-2xl border border-neutral-300 text-sm font-semibold hover:bg-neutral-100"
              href={API_DOCS_URL}
              target="_blank"
              rel="noreferrer"
            >
              Ver API en vivo
            </a>
          </div>
          <ul className="mt-6 grid gap-2 text-sm text-neutral-700 list-disc pl-5">
            <li>Privacidad por diseño: análisis local/servidor con mínima retención.</li>
            <li>Explicaciones simples y alto contraste (accesible para baja visión).</li>
            <li>Compatible con apps de mensajería y correo mediante compartir texto.</li>
          </ul>
        </div>
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.1 }}
          className="rounded-3xl border border-neutral-200 bg-white p-4 shadow-sm"
        >
          {/* Demo card mock */}
          <div className="aspect-[4/3] w-full rounded-2xl bg-neutral-100 flex items-center justify-center text-neutral-500">
            Vista previa del prototipo (Figma)
          </div>
          <div className="mt-3 flex items-center justify-between">
            <span className="text-sm text-neutral-600">App Fraude Cero</span>
            <a
              className="text-sm font-semibold underline"
              href={FIGMA_URL}
              target="_blank"
              rel="noreferrer"
            >
              Abrir Figma
            </a>
          </div>
        </motion.div>
      </section>

      {/* Features */}
      <section className="mx-auto max-w-6xl px-4 pb-4">
        <div className="grid gap-4 md:grid-cols-3">
          {[
            {
              title: 'Detección conversacional',
              desc: 'Analiza el texto de los mensajes para identificar señales típicas de fraude.',
            },
            {
              title: 'Acciones en 1–2 toques',
              desc: 'Bloquear, marcar como segura o reportar con confirmación clara.',
            },
            {
              title: 'Accesible y claro',
              desc: 'Tipografía grande, alto contraste y lenguaje no técnico.',
            },
          ].map((f, i) => (
            <div
              key={i}
              className="rounded-3xl border border-neutral-200 bg-white p-5 shadow-sm"
            >
              <h3 className="text-lg font-semibold">{f.title}</h3>
              <p className="mt-2 text-neutral-700 text-sm">{f.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* How it works */}
      <section className="mx-auto max-w-6xl px-4 py-10">
        <h2 className="text-2xl font-extrabold">Cómo funciona</h2>
        <ol className="mt-4 grid gap-4 md:grid-cols-3">
          {[
            {
              n: 1,
              t: 'Comparte el mensaje',
              d: 'Pega el texto o usa compartir desde tu app de mensajería/correo.',
            },
            { n: 2, t: 'Análisis y score', d: 'El motor evalúa riesgo y lo explica en lenguaje simple.' },
            { n: 3, t: 'Toma acción', d: 'Bloquea, denuncia o marca como seguro y guarda historial.' },
          ].map((s) => (
            <li key={s.n} className="rounded-3xl border border-neutral-200 bg-white p-5 shadow-sm">
              <div className="text-4xl font-black">{s.n}</div>
              <div className="mt-2 text-lg font-semibold">{s.t}</div>
              <div className="mt-1 text-sm text-neutral-700">{s.d}</div>
            </li>
          ))}
        </ol>
      </section>

      {/* Playground */}
      <section ref={demoRef} className="mx-auto max-w-6xl px-4 py-12">
        <h2 className="text-2xl font-extrabold">Playground del API</h2>
        <p className="mt-2 text-neutral-700 max-w-3xl">
          Prueba el endpoint <code className="px-1 rounded bg-neutral-100">POST /api/analizar</code>.
          Para la demo, usa ejemplos ficticios y evita datos personales.
        </p>

        <div className="mt-6 grid gap-4 md:grid-cols-2">
          <div className="rounded-3xl border border-neutral-200 bg-white p-5 shadow-sm">
            <label htmlFor="msg" className="block text-sm font-semibold">
              Mensaje a analizar
            </label>
            <textarea
              id="msg"
              value={msg}
              onChange={(e) => setMsg(e.target.value)}
              className="mt-2 w-full h-44 resize-y rounded-2xl border border-neutral-300 px-3 py-2 text-neutral-900 focus:outline-none focus:ring-2 focus:ring-neutral-900"
              placeholder="Pega aquí el texto sospechoso…"
            />
            <div className="mt-3 flex flex-wrap gap-2">
              {examples.map((ex, i) => (
                <button
                  key={i}
                  onClick={() => setMsg(ex)}
                  className="px-3 py-2 rounded-xl text-xs border border-neutral-300 hover:bg-neutral-100"
                >
                  Ejemplo {i + 1}
                </button>
              ))}
              <button
                onClick={handleAnalyze}
                className="ml-auto px-4 py-2 rounded-xl bg-neutral-900 text-white text-sm font-semibold hover:opacity-90"
                disabled={loading}
              >
                {loading ? 'Analizando…' : 'Analizar'}
              </button>
            </div>
            {error && (
              <div className="mt-3 rounded-xl border border-red-200 bg-red-50 p-3 text-red-800 text-sm">
                {error}
              </div>
            )}
          </div>

          <div className="rounded-3xl border border-neutral-200 bg-white p-5 shadow-sm overflow-hidden">
            <div className="flex items-center justify-between">
              <div className="text-sm font-semibold">Respuesta</div>
              <div className="text-xs text-neutral-500">/api/analizar → backend</div>
            </div>
            <pre className="mt-2 h-64 overflow-auto rounded-2xl bg-neutral-50 p-3 text-xs">
{result ? JSON.stringify(result, null, 2) : `{
  "score": 0.92,
  "riesgo": "alto",
  "motivos": ["Solicita clave", "Urgencia inusual"],
  "sugerencias": ["No respondas", "Contacta a tu banco por canal oficial"]
}`}
            </pre>
          </div>
        </div>

        <div className="mt-4 text-xs text-neutral-500">
          Nota: este frontend llama a <code>/api/analizar</code> (proxy server-side) para evitar CORS.
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-neutral-200 bg-white">
        <div className="mx-auto max-w-6xl px-4 py-6 text-sm text-neutral-600 flex flex-col md:flex-row gap-3 md:items-center md:justify-between">
          <div>© {new Date().getFullYear()} Fraude Cero</div>
          <div className="flex gap-4">
            <a className="underline" href={API_DOCS_URL} target="_blank" rel="noreferrer">
              API Docs
            </a>
            <a className="underline" href={FIGMA_URL} target="_blank" rel="noreferrer">
              Prototipo Figma
            </a>
          </div>
        </div>
      </footer>
    </div>
  )
}
